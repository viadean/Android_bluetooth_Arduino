# Arduino-Bluetooth-Basic
Control a LED using your smartphone via bluetooth
Tutorial : http://www.viadean.com/android_bluetooth_arduino.html#_jcp=4_57



